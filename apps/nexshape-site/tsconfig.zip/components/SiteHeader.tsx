import Link from "next/link";

const NAV = [
  { href: "/produtos/fitness", label: "Fitness" },
  { href: "/produtos/dental", label: "Dental" },
  { href: "/produtos/chat", label: "Chat" },
  { href: "/produtos/credit", label: "Credit" },
  { href: "/sobre", label: "Sobre" },
];

export function SiteHeader() {
  return (
    <header className="border-b border-slate-200 bg-white">
      <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-4 px-4 py-4">
        <Link href="/" className="text-lg font-semibold text-slate-900">
          PaivaTech<span className="text-slate-500"> · </span>
          <span className="text-indigo-600">NexShape</span>
        </Link>
        <nav className="flex flex-wrap items-center gap-3 text-sm font-medium text-slate-700">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="rounded hover:text-indigo-600 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
            >
              {item.label}
            </Link>
          ))}
          <Link
            href="/contato"
            className="rounded bg-indigo-600 px-3 py-2 text-white hover:bg-indigo-700 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-800"
          >
            Contato
          </Link>
        </nav>
      </div>
    </header>
  );
}
