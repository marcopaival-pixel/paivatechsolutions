import type { MetadataRoute } from "next";
import { PRODUCT_SLUGS } from "@/lib/content/products";
import { siteUrl } from "@/lib/site";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = siteUrl();
  const staticPaths = ["", "/sobre", "/contato", "/contato/enviado", "/privacidade", "/termos"];
  const entries: MetadataRoute.Sitemap = [
    ...staticPaths.map((path) => ({
      url: `${base}${path || "/"}`,
      lastModified: new Date(),
      changeFrequency: "weekly" as const,
      priority: path === "" ? 1 : 0.7,
    })),
    ...PRODUCT_SLUGS.map((slug) => ({
      url: `${base}/produtos/${slug}`,
      lastModified: new Date(),
      changeFrequency: "weekly" as const,
      priority: 0.8,
    })),
  ];
  return entries;
}
