# NexShape site (institucional)

App Next.js (App Router) para o projeto piloto PaivaTech Solutions / suite NexShape.

## Desenvolvimento

```bash
npm install
cp .env.example .env.local
npm run dev
```

## Variáveis de ambiente

Veja `.env.example`. `NEXT_PUBLIC_SITE_URL` alimenta metadata, `sitemap.xml` e `robots.txt`.

## Build

```bash
npm run build
npm run start
```

Especificação de contato (OpenAPI) e demais artefatos do Builder: `Fabrica/outputs/2026-05-13-projeto-piloto-builder/`.
