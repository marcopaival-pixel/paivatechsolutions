import Link from "next/link";

const FOOTER = [
  { href: "/produtos/fitness", label: "NexShape Fitness" },
  { href: "/produtos/dental", label: "NexShape Dental" },
  { href: "/produtos/chat", label: "NexShape Chat" },
  { href: "/produtos/credit", label: "NexShape Credit" },
  { href: "/privacidade", label: "Privacidade" },
  { href: "/termos", label: "Termos" },
  { href: "/contato", label: "Contato" },
];

export function SiteFooter() {
  return (
    <footer className="mt-16 border-t border-slate-200 bg-slate-50 py-10 text-sm text-slate-600">
      <div className="mx-auto max-w-5xl px-4">
        <div className="flex flex-wrap gap-x-6 gap-y-3">
          {FOOTER.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className="hover:text-indigo-600 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
            >
              {l.label}
            </Link>
          ))}
        </div>
        <p className="mt-6 text-slate-500">
          © {new Date().getFullYear()} PaivaTech Solutions · Suite NexShape
        </p>
      </div>
    </footer>
  );
}
