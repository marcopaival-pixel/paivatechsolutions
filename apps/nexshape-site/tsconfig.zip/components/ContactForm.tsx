"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  contactFormSchema,
  type ContactFormValues,
  buildContactApiBody,
} from "@/lib/contact/form-schema";
import { productInterestEnum, type ProductInterest } from "@/lib/contact/schema";
import { PRIVACY_POLICY_VERSION } from "@/lib/legal";

const PRODUCT_OPTIONS = productInterestEnum.options;

interface ContactFormProps {
  defaultProduct?: ProductInterest;
}

export function ContactForm({ defaultProduct }: ContactFormProps) {
  const router = useRouter();
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<ContactFormValues>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      fullName: "",
      email: "",
      phone: "",
      companyName: "",
      productInterest: defaultProduct,
      message: "",
      website: "",
      consentPolicy: false,
      sourcePath: "",
    },
  });

  async function onSubmit(values: ContactFormValues) {
    const body = buildContactApiBody(values, PRIVACY_POLICY_VERSION);
    if (typeof window !== "undefined") {
      (body as Record<string, unknown>).sourcePath = window.location.pathname + window.location.search;
    }

    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = (await res.json().catch(() => ({}))) as Record<string, unknown>;

      if (res.ok && data.ok === true) {
        router.push("/contato/enviado");
        return;
      }

      if (res.status === 422 && Array.isArray(data.issues)) {
        for (const issue of data.issues as Array<{ path?: string; messagePt?: string }>) {
          const p = issue.path ?? "";
          const paths = ["fullName", "email", "phone", "companyName", "productInterest", "message", "website"];
          if (paths.includes(p)) {
            setError(p as keyof ContactFormValues, { message: issue.messagePt || "Campo inválido." });
          } else if (p === "consentAccepted") {
            setError("consentPolicy", { message: issue.messagePt || "Aceite a política de privacidade." });
          }
        }
        return;
      }

      setError("root.server", { message: "Não foi possível enviar. Tente novamente em instantes." });
    } catch {
      setError("root.server", { message: "Erro de rede. Tente novamente." });
    }
  }

  return (
    <form className="relative space-y-6" onSubmit={handleSubmit(onSubmit)} noValidate>
      <div className="absolute -left-[9999px] h-px w-px overflow-hidden opacity-0" aria-hidden tabIndex={-1}>
        <label htmlFor="trap-website">Website</label>
        <input id="trap-website" type="text" tabIndex={-1} autoComplete="off" {...register("website")} />
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor="fullName" className="mb-1 block text-sm font-medium text-slate-700">
            Nome completo <span className="text-red-600">*</span>
          </label>
          <input
            id="fullName"
            autoComplete="name"
            className="w-full rounded border border-slate-300 px-3 py-2 text-slate-900 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            {...register("fullName")}
            aria-invalid={errors.fullName ? true : undefined}
            aria-describedby={errors.fullName ? "fullName-err" : undefined}
          />
          {errors.fullName && (
            <p id="fullName-err" className="mt-1 text-sm text-red-600" role="alert">
              {errors.fullName.message}
            </p>
          )}
        </div>

        <div>
          <label htmlFor="email" className="mb-1 block text-sm font-medium text-slate-700">
            E-mail <span className="text-red-600">*</span>
          </label>
          <input
            id="email"
            type="email"
            autoComplete="email"
            className="w-full rounded border border-slate-300 px-3 py-2 text-slate-900 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            {...register("email")}
            aria-invalid={errors.email ? true : undefined}
            aria-describedby={errors.email ? "email-err" : undefined}
          />
          {errors.email && (
            <p id="email-err" className="mt-1 text-sm text-red-600" role="alert">
              {errors.email.message}
            </p>
          )}
        </div>

        <div>
          <label htmlFor="phone" className="mb-1 block text-sm font-medium text-slate-700">
            Telefone (Brasil) <span className="text-red-600">*</span>
          </label>
          <input
            id="phone"
            type="tel"
            autoComplete="tel"
            placeholder="+55 ..."
            className="w-full rounded border border-slate-300 px-3 py-2 text-slate-900 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            {...register("phone")}
            aria-invalid={errors.phone ? true : undefined}
            aria-describedby={errors.phone ? "phone-err" : undefined}
          />
          {errors.phone && (
            <p id="phone-err" className="mt-1 text-sm text-red-600" role="alert">
              {errors.phone.message}
            </p>
          )}
        </div>

        <div>
          <label htmlFor="companyName" className="mb-1 block text-sm font-medium text-slate-700">
            Empresa <span className="text-red-600">*</span>
          </label>
          <input
            id="companyName"
            autoComplete="organization"
            className="w-full rounded border border-slate-300 px-3 py-2 text-slate-900 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            {...register("companyName")}
            aria-invalid={errors.companyName ? true : undefined}
            aria-describedby={errors.companyName ? "companyName-err" : undefined}
          />
          {errors.companyName && (
            <p id="companyName-err" className="mt-1 text-sm text-red-600" role="alert">
              {errors.companyName.message}
            </p>
          )}
        </div>

        <div className="sm:col-span-2">
          <label htmlFor="productInterest" className="mb-1 block text-sm font-medium text-slate-700">
            Produto de interesse <span className="text-red-600">*</span>
          </label>
          <select
            id="productInterest"
            className="w-full rounded border border-slate-300 bg-white px-3 py-2 text-slate-900 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            {...register("productInterest")}
            aria-invalid={errors.productInterest ? true : undefined}
            aria-describedby={errors.productInterest ? "prod-err" : undefined}
          >
            <option value="" disabled>
              Selecione uma opção
            </option>
            {PRODUCT_OPTIONS.map((opt) => (
              <option key={opt} value={opt}>
                {opt === "Dental"
                  ? "NexShape Dental"
                  : opt === "Fitness"
                    ? "NexShape Fitness"
                    : opt === "Chat"
                      ? "NexShape Chat"
                      : opt === "Credit"
                        ? "NexShape Credit"
                        : "Geral / outro"}
              </option>
            ))}
          </select>
          {errors.productInterest && (
            <p id="prod-err" className="mt-1 text-sm text-red-600" role="alert">
              {errors.productInterest.message}
            </p>
          )}
        </div>
      </div>

      <div>
        <label htmlFor="message" className="mb-1 block text-sm font-medium text-slate-700">
          Mensagem <span className="text-red-600">*</span>
        </label>
        <textarea
          id="message"
          rows={5}
          className="w-full rounded border border-slate-300 px-3 py-2 text-slate-900 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
          {...register("message")}
          aria-invalid={errors.message ? true : undefined}
          aria-describedby={errors.message ? "message-err" : undefined}
        />
        {errors.message && (
          <p id="message-err" className="mt-1 text-sm text-red-600" role="alert">
            {errors.message.message}
          </p>
        )}
      </div>

      <div className="flex items-start gap-2">
        <input id="consentPolicy" type="checkbox" {...register("consentPolicy")} className="mt-1 h-4 w-4 accent-indigo-600" />
        <label htmlFor="consentPolicy" className="text-sm text-slate-700">
          Li e aceito a{" "}
          <Link href="/privacidade" className="text-indigo-600 underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2">
            Política de Privacidade
          </Link>{" "}
          <span className="text-red-600">*</span>
        </label>
      </div>
      {errors.consentPolicy && (
        <p className="text-sm text-red-600" role="alert">
          {errors.consentPolicy.message}
        </p>
      )}

      {errors.root?.server && (
        <p className="rounded border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700" role="alert">
          {errors.root.server.message}
        </p>
      )}

      <button
        type="submit"
        disabled={isSubmitting}
        className="rounded bg-indigo-600 px-5 py-2.5 font-medium text-white hover:bg-indigo-700 disabled:opacity-60 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-800"
      >
        {isSubmitting ? "Enviando..." : "Enviar mensagem"}
      </button>
    </form>
  );
}
