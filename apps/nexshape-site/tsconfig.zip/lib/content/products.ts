import type { ProductInterest } from "@/lib/contact/schema";

export const PRODUCT_SLUGS = ["fitness", "dental", "chat", "credit"] as const;
export type ProductSlug = (typeof PRODUCT_SLUGS)[number];

export function isProductSlug(s: string): s is ProductSlug {
  return (PRODUCT_SLUGS as readonly ProductSlug[]).includes(s as ProductSlug);
}

/** Prefill do formulário na página `/produtos/[slug]` (enum OpenAPI). */
export function productInterestFromProductSlug(slug: string): ProductInterest | undefined {
  if (!isProductSlug(slug)) return undefined;
  const map: Record<ProductSlug, ProductInterest> = {
    fitness: "Fitness",
    dental: "Dental",
    chat: "Chat",
    credit: "Credit",
  };
  return map[slug];
}

interface ProductContent {
  slug: ProductSlug;
  title: string;
  short: string;
}

export const PRODUCTS: Record<ProductSlug, ProductContent> = {
  fitness: {
    slug: "fitness",
    title: "NexShape Fitness",
    short: "Gestão para academias e estúdios: operação, relacionamento com alunos e visão financeira em um só lugar.",
  },
  dental: {
    slug: "dental",
    title: "NexShape Dental",
    short: "Organize recepção, agenda e administrativo da sua clínica odontológica com foco em produtividade.",
  },
  chat: {
    slug: "chat",
    title: "NexShape Chat",
    short: "Automatize atendimento e integração com WhatsApp e outros canais para escalar o suporte sem perder o tom humano.",
  },
  credit: {
    slug: "credit",
    title: "NexShape Credit",
    short: "Apoio a análises cadastrais e decisão com dados de CPF/CNPJ, veículos e demais informações — sempre com uso responsável.",
  },
};
