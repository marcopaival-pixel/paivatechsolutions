import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Sobre",
  description: "PaivaTech Solutions e a missão por trás da suite NexShape.",
};

export default function SobrePage() {
  return (
    <article className="max-w-none space-y-4">
      <h1 className="text-3xl font-bold text-slate-900">Sobre a PaivaTech Solutions</h1>
      <p className="text-slate-600">
        Somos uma empresa de tecnologia focada em produtos que organizam o dia a dia de negócios reais — academias,
        clínicas, equipes de atendimento e operações que dependem de dados com responsabilidade.
      </p>
      <p className="text-slate-600">
        A <strong>suite NexShape</strong> reúne módulos especializados (Fitness, Dental, Chat e Credit) com uma visão
        comum: reduzir atrito operacional, melhorar a experiência de clientes e parceiros, e apoiar decisões com
        transparência e respeito à privacidade.
      </p>
      <h2 className="mt-8 text-xl font-semibold text-slate-900">Como trabalhamos</h2>
      <ul className="list-disc space-y-2 pl-5 text-slate-600">
        <li>Desenvolvimento incremental e segurança em primeiro lugar.</li>
        <li>Contratos claros e alinhamento com LGPD onde aplicável.</li>
        <li>Suporte humano quando a automação não é suficiente.</li>
      </ul>
      <p className="mt-8">
        <Link href="/contato" className="font-medium text-indigo-600 underline hover:no-underline">
          Entre em contato
        </Link>{" "}
        para conversar sobre o seu cenário.
      </p>
    </article>
  );
}
