import type { Metadata } from "next";
import { ContactForm } from "@/components/ContactForm";
import { productInterestFromSearchParam } from "@/lib/contact/query-param";

export const metadata: Metadata = {
  title: "Contato",
  description: "Envie sua mensagem à equipe PaivaTech Solutions / NexShape.",
};

export const dynamic = "force-dynamic";

export default async function ContatoPage({
  searchParams,
}: {
  searchParams: Promise<{ produto?: string }>;
}) {
  const sp = await searchParams;
  const preset = productInterestFromSearchParam(sp.produto);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-slate-900">Contato</h1>
        <p className="mt-2 max-w-xl text-slate-600">
          Preencha todos os campos. Responderemos o mais rápido possível. Campos marcados com{" "}
          <span className="text-red-600">*</span> são obrigatórios.
        </p>
      </div>
      <ContactForm key={preset ?? "none"} defaultProduct={preset} />
    </div>
  );
}
