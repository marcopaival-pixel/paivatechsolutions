import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ContactForm } from "@/components/ContactForm";
import { isProductSlug, PRODUCTS, productInterestFromProductSlug } from "@/lib/content/products";

type Props = { params: Promise<{ slug: string }> };

export async function generateStaticParams() {
  return [{ slug: "fitness" }, { slug: "dental" }, { slug: "chat" }, { slug: "credit" }];
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  if (!isProductSlug(slug)) return { title: "Produto" };
  const p = PRODUCTS[slug];
  return {
    title: p.title,
    description: p.short,
  };
}

export default async function ProdutoPage({ params }: Props) {
  const { slug } = await params;
  if (!isProductSlug(slug)) notFound();

  const product = PRODUCTS[slug];
  const defaultProduct = productInterestFromProductSlug(slug);

  return (
    <div className="space-y-10">
      <article>
        <nav className="mb-4 text-sm text-slate-500">
          <Link href="/" className="hover:text-indigo-600">
            Início
          </Link>
          <span className="mx-2">/</span>
          <span className="text-slate-700">Produtos</span>
          <span className="mx-2">/</span>
          <span className="text-slate-900">{product.title}</span>
        </nav>
        <h1 className="text-3xl font-bold text-slate-900">{product.title}</h1>
        <p className="mt-4 max-w-2xl text-lg text-slate-600">{product.short}</p>

        {slug === "credit" && (
          <aside
            className="mt-8 rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-950"
            role="note"
          >
            <strong className="font-semibold">Uso responsável e conformidade:</strong> funcionalidades de crédito e
            consulta cadastral devem ser utilizadas apenas com base legal válida (incluindo consentimento quando
            exigido), finalidade específica e medidas de segurança adequadas. Não prometemos aprovação de crédito nem
            substituímos análise humana ou regulatória.
          </aside>
        )}

        <div className="mt-8 flex flex-wrap gap-3">
          <Link
            href={`/contato?produto=${slug}`}
            className="rounded bg-indigo-600 px-4 py-2.5 font-medium text-white hover:bg-indigo-700 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-800"
          >
            Solicitar contato
          </Link>
          <Link
            href="/contato"
            className="rounded border border-slate-300 px-4 py-2.5 font-medium text-slate-800 hover:border-slate-400 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
          >
            Contato geral
          </Link>
        </div>
      </article>

      <section className="border-t border-slate-200 pt-10">
        <h2 className="text-xl font-semibold text-slate-900">Envie uma mensagem sobre este produto</h2>
        <p className="mt-2 text-sm text-slate-600">
          O produto de interesse já vem selecionado; você pode alterar antes de enviar.
        </p>
        <div className="mt-6 max-w-2xl">
          <ContactForm key={slug} defaultProduct={defaultProduct} />
        </div>
      </section>
    </div>
  );
}
