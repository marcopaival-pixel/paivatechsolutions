import type { Metadata } from "next";
import Link from "next/link";
import { PRIVACY_POLICY_VERSION } from "@/lib/legal";

export const metadata: Metadata = {
  title: "Política de Privacidade",
  description: "Como tratamos dados pessoais no site institucional PaivaTech Solutions / NexShape.",
};

export default function PrivacidadePage() {
  return (
    <article className="max-w-none space-y-6">
      <h1 className="text-3xl font-bold text-slate-900">Política de Privacidade</h1>
      <p className="text-sm text-slate-500">
        Versão {PRIVACY_POLICY_VERSION} · Aplicável ao site institucional e ao formulário de contato deste projeto.
      </p>

      <h2 className="text-xl font-semibold text-slate-900">1. Controlador</h2>
      <p className="text-slate-600">
        Esta política descreve o tratamento de dados no contexto do site institucional da PaivaTech Solutions e da suite
        NexShape (páginas informativas e canal de contato). Para dados tratados por produtos contratados, aplicam-se os
        termos específicos do contrato e encarregamento indicado quando houver.
      </p>

      <h2 className="text-xl font-semibold text-slate-900">2. Dados coletados no formulário</h2>
      <p className="text-slate-600">
        Ao usar o formulário de contato, podemos solicitar nome, e-mail, telefone, empresa, produto de interesse,
        mensagem e confirmação de leitura desta política. Também podemos registrar o caminho da página de origem
        (sourcePath) para contexto da solicitação.
      </p>

      <h2 className="text-xl font-semibold text-slate-900">3. Finalidades</h2>
      <ul className="list-disc space-y-2 pl-5 text-slate-600">
        <li>Responder solicitações e oportunidades comerciais legítimas.</li>
        <li>Registrar consentimento e versão da política quando aplicável.</li>
        <li>Prevenir abuso e spam (incluindo medidas técnicas como campos ocultos).</li>
      </ul>

      <h2 className="text-xl font-semibold text-slate-900">4. Base legal (LGPD)</h2>
      <p className="text-slate-600">
        O tratamento tende a se apoiar em execução de procedimentos preliminares relacionados a contrato a pedido do
        titular, legítimo interesse em responder contatos, e consentimento quando indicado no fluxo. Ajustes finos
        dependem do seu caso e do produto — consulte nossa equipe.
      </p>

      <h2 className="text-xl font-semibold text-slate-900">5. Compartilhamento</h2>
      <p className="text-slate-600">
        Dados podem ser encaminhados a sistemas de CRM ou fila interna via integração configurada pela operação
        (webhook), sempre com medidas de segurança compatíveis. Não vendemos dados pessoais.
      </p>

      <h2 className="text-xl font-semibold text-slate-900">6. Direitos do titular</h2>
      <p className="text-slate-600">
        Você pode solicitar acesso, correção, anonimização, portabilidade, eliminação e informações sobre
        compartilhamentos, nos limites da lei, entrando em contato pelos canais indicados no site quando disponíveis.
      </p>

      <h2 className="text-xl font-semibold text-slate-900">7. Retenção</h2>
      <p className="text-slate-600">
        Mantemos registros pelo tempo necessário para cumprir finalidades acima, obrigações legais e resolução de
        pendências relacionadas ao contato.
      </p>

      <p className="mt-8 text-slate-600">
        Para falar com a equipe:{" "}
        <Link href="/contato" className="font-medium text-indigo-600 underline hover:no-underline">
          formulário de contato
        </Link>
        .
      </p>
    </article>
  );
}
