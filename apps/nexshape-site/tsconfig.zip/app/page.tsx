import type { Metadata } from "next";
import Link from "next/link";
import { PRODUCT_SLUGS, PRODUCTS, type ProductSlug } from "@/lib/content/products";

export const metadata: Metadata = {
  title: "Início",
  description:
    "Suite NexShape: soluções em gestão Fitness, Dental, atendimento com Chat e análises com Credit.",
};

export default function HomePage() {
  return (
    <div className="space-y-12">
      <section className="space-y-4">
        <p className="text-sm font-medium uppercase tracking-wide text-indigo-600">PaivaTech Solutions</p>
        <h1 className="text-balance text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">
          Operacional claro para negócios que precisam crescer com responsabilidade
        </h1>
        <p className="max-w-2xl text-lg text-slate-600">
          Apresentamos a suite <strong>NexShape</strong>: produtos especializados em Fitness, clínicas odontológicas,
          automação de atendimento e apoio a decisões cadastrais e de crédito — com foco em conformidade e
          privacidade.
        </p>
        <div className="flex flex-wrap gap-3 pt-2">
          <Link
            href="/contato"
            className="rounded bg-indigo-600 px-4 py-2.5 font-medium text-white hover:bg-indigo-700 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-800"
          >
            Falar com a equipe
          </Link>
          <Link
            href="/sobre"
            className="rounded border border-slate-300 px-4 py-2.5 font-medium text-slate-800 hover:border-slate-400 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
          >
            Conheça a empresa
          </Link>
        </div>
      </section>

      <section className="space-y-4">
        <h2 className="text-xl font-semibold text-slate-900">Produtos NexShape</h2>
        <ul className="grid gap-4 sm:grid-cols-2">
          {PRODUCT_SLUGS.map((slug: ProductSlug) => {
            const p = PRODUCTS[slug];
            return (
              <li key={slug}>
                <Link
                  href={`/produtos/${slug}`}
                  className="block h-full rounded-lg border border-slate-200 bg-slate-50/80 p-5 transition hover:border-indigo-200 hover:bg-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                >
                  <h3 className="font-semibold text-indigo-700">{p.title}</h3>
                  <p className="mt-2 text-sm text-slate-600">{p.short}</p>
                  <span className="mt-3 inline-block text-sm font-medium text-indigo-600">
                    Saiba mais →
                  </span>
                </Link>
              </li>
            );
          })}
        </ul>
      </section>
    </div>
  );
}
