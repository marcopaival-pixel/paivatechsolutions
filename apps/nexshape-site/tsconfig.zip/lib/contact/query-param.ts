import type { ProductInterest } from "./schema";

/** Maps `?produto=` short codes used in UX to OpenAPI enum (English product names). */
const MAP: Record<string, ProductInterest> = {
  f: "Fitness",
  fitness: "Fitness",
  dental: "Dental",
  d: "Dental",
  chat: "Chat",
  c: "Chat",
  credit: "Credit",
  cr: "Credit",
  geral: "Geral",
  g: "Geral",
};

export function productInterestFromSearchParam(raw: string | undefined): ProductInterest | undefined {
  if (raw === undefined || raw === "") return undefined;
  const k = raw.toLowerCase().trim();
  return MAP[k];
}
