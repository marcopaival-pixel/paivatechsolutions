import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Termos de Uso",
  description: "Termos de uso do site institucional PaivaTech Solutions / NexShape.",
};

export default function TermosPage() {
  return (
    <article className="max-w-none space-y-6">
      <h1 className="text-3xl font-bold text-slate-900">Termos de Uso</h1>
      <p className="text-sm text-slate-500">Site institucional — versão orientativa para o projeto piloto.</p>

      <h2 className="text-xl font-semibold text-slate-900">1. Aceite</h2>
      <p className="text-slate-600">
        Ao navegar neste site, você concorda com estes termos na medida aplicável ao uso informativo e ao envio do
        formulário de contato. Contratos específicos de produtos substituem disposições conflitantes quando existirem.
      </p>

      <h2 className="text-xl font-semibold text-slate-900">2. Conteúdo</h2>
      <p className="text-slate-600">
        As descrições de produtos têm caráter informativo e podem mudar conforme roadmap e requisitos de mercado e
        regulatório. Materiais não constituem garantia de desempenho ou disponibilidade.
      </p>

      <h2 className="text-xl font-semibold text-slate-900">3. NexShape Credit</h2>
      <p className="text-slate-600">
        Mensagens relacionadas a crédito e consultas não configuram decisão de crédito. O uso deve observar lei e boas
        práticas; a PaivaTech Solutions pode recusar atendimento que pareça ilegal ou incompatível com políticas
        internas.
      </p>

      <h2 className="text-xl font-semibold text-slate-900">4. Links e terceiros</h2>
      <p className="text-slate-600">
        O site pode referenciar serviços de terceiros; não nos responsabilizamos por conteúdo ou disponibilidade
        externa.
      </p>

      <h2 className="text-xl font-semibold text-slate-900">5. Limitação</h2>
      <p className="text-slate-600">
        Na máxima extensão permitida pela lei aplicável, isentamos danos indiretos decorrentes de indisponibilidade do
        site ou uso de materiais apenas informativos. Questões jurídicas específicas serão tratadas conforme jurisdição
        e contratos vigentes.
      </p>

      <p className="mt-8 text-slate-600">
        Dúvidas:{" "}
        <Link href="/contato" className="font-medium text-indigo-600 underline hover:no-underline">
          Contato
        </Link>
        {" · "}
        <Link href="/privacidade" className="font-medium text-indigo-600 underline hover:no-underline">
          Privacidade
        </Link>
      </p>
    </article>
  );
}
